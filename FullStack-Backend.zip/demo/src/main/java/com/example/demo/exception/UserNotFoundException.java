package com.example.demo.exception;

public class UserNotFoundException extends RuntimeException{

    
    public  UserNotFoundException(String email){
        super("Could not find user with email:"+email);
    }
    
    public UserNotFoundException(String email, String password){
        super("Invalid credentials for user: "+email+" with the provided password");
    }
    
    public UserNotFoundException(Long id){
        super("Could not found the user with id " + id);
    }
}
