import React, { useState } from "react";
import "./login.css";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
    const navigate=useNavigate();
    const [ password, setPasswordValue ] = useState("");
    const [ userId, setUserIdValue ] = useState("");

    const setPassword = (e) => {
        //console.log(e.target.value);
        setPasswordValue(e.target.value);
    }

    const setUserId = (e) => {
        setUserIdValue(e.target.value);
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        //API CALL
        console.log("This is our data." + userId + "  " + password)
        const data={
            "userId":userId,
            "password":password
        }
        try{
            const response= await axios.post("http://localhost:8080/loginUser",data);
            console.log("This is the response  "+ response.data)
            //console.log(response);
            if(!response.data){
                alert("Invalid Credentials");
            }
            else{
                alert("Login Successful")
                navigate("/");

            }
        }
        catch(error){
            console.error(error);
            if(error.response && error.response.status ===400){
                alert(error.response.data.userId);
            }
            else if(error.response.status ===401){
                alert(error.response.data.errorMessage)

                
            }
        }
    };

    return (
        <div className="addUser">
            <h3>Log in</h3>
            <form className="addUserForm" onSubmit={handleSubmit}>
                <div className="inputGroup">
                    <label htmlFor="email">Email:</label>
                    <input
                        // type="email"
                        id="email"
                        name="email"
                        autoComplete="off"
                        placeholder="Enter your Email"
                        value={userId}
                        onChange={setUserId}
                    />
                    <label htmlFor="Password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        autoComplete="off"
                        placeholder="Enter your Password"
                        value={password}
                        onChange={setPassword}
                    />
                    <button type="submit" className="btn btn-primary">
                        Login
                    </button>
                </div>
            </form>
            <div className="login">
                <p>Don't have Account? </p>
                <Link to="/Signup" type="submit" className="btn btn-success">
                    Sign Up
                </Link>
            </div>
        </div>
    );
};

export default Login;